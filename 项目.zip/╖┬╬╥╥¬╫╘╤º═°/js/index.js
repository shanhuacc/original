// 快捷方式显示检测
$(window).scroll(function() {
	//滚动条距离顶部的距离
	var s_top = $(document).scrollTop();
	if (s_top > 150) {
		$("#operation_left,#operation_right").css("display", "block");
	} else {
		$("#operation_left,#operation_right").css("display", "none");
	};
})
// 快捷方式显示检测完成
$(function() {
	

//轮播图开始	
////全局变量
	var c = 0;
	var zxw = $("#zxw a");
	var nav = $("#nav li");

	//1.定义自动切换效果
	function abc() {
		c++; //1  4
		if (c == zxw.length) {
			// $("#zxw").css({left:0});
			$("#zxw").animate({
				left: 0
			}, 1000);
			c = 0;
		};

		// $("#zxw").animate({left:c*-1200+"px"},2000);

		if (c == 0) {
			// console.log(c);
			nav.eq(0).addClass("active").siblings("li").removeClass("active");
			$("#ppt").attr("class", "bg0");
		} else {
			// console.log(c);
			$("#zxw").animate({
				left: c * -1200 + "px"
			}, 1000);
			nav.eq(c).addClass("active").siblings("li").removeClass("active");
			$("#ppt").attr("class", "bg" + c);
		};
	};


	//鼠标单击小圆点切换效果
	function bcd(e) {
		c = e.index();
		nav.eq(c).addClass("active").siblings("li").removeClass("active");
		$("#zxw").animate({
			left: c * -1200 + "px"
		}, 500);
		$("#ppt").attr("class", "bg" + c);
	};
	//左耳朵单击切换
	function prev() {
		c--;
		if (c < 0) {
			// 如果图片索引值到了首端,那么再把该索引值赋值给最后一个
			c = nav.length - 1;
		}
		nav.eq(c).addClass("active").siblings("li").removeClass("active");
		$("#zxw").animate({
			left: c * -1200 + "px"
		}, 500);
		$("#ppt").attr("class", "bg" + c);
	};

	//右耳朵单击切换
	function next() {
		c++;
		if (c > nav.length - 1) {
			c = 0;
		}
		nav.eq(c).addClass("active").siblings("li").removeClass("active");
		$("#zxw").animate({
			left: c * -1200 + "px"
		}, 500);
		$("#ppt").attr("class", "bg" + c);

	};

	//定时器,每5秒执行一次
	var time = setInterval(abc, 5000);
var time1;
	//鼠标移入#slide元素中,停止定时器
	$("#slide").mouseenter(function() {
		clearInterval(time);
		clearInterval(time1);
	});

	//鼠标移出#slide元素后,开始定时器
	$("#slide").mouseleave(function() {
		 time1 = setInterval(abc, 5000);
	});


	//鼠标单击小圆点事件
	$("#nav li").click(function() {
		bcd($(this));
	});

	//左耳朵单击事件
	$("#prev").click(function() {
		prev();
	});

	//右耳朵单击事件
	$("#next").click(function() {
		next();
	});
	// 悬浮栏制作开始
	var zxw11=$("#operation_left a");
	function switch_1(x) {
			var c = x.index();
			console.log(c);
			zxw11.eq(c-1).addClass("active").siblings("a").removeClass("active");
		};
	$("#operation_left a").click(function() {
		switch_1($(this));
	});
	// 悬浮栏制作结束
})

//轮播图结束

